# OpenapiClient::SearchArtworks200ResponseArtworksInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **title** | **String** |  | [optional] |
| **image** | **String** |  | [optional] |
| **id** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchArtworks200ResponseArtworksInner.new(
  title: null,
  image: null,
  id: null
)
```

