
# SearchArtworks200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **available** | **kotlin.Int** |  |  [optional] |
| **number** | **kotlin.Int** |  |  [optional] |
| **offset** | **kotlin.Int** |  |  [optional] |
| **artworks** | [**kotlin.collections.List&lt;SearchArtworks200ResponseArtworksInner&gt;**](SearchArtworks200ResponseArtworksInner.md) |  |  [optional] |



