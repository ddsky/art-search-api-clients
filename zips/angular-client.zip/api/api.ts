export * from './art.service';
import { ArtService } from './art.service';
export const APIS = [ArtService];
