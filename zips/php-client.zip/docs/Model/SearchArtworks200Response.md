# # SearchArtworks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **int** |  | [optional]
**number** | **int** |  | [optional]
**offset** | **int** |  | [optional]
**artworks** | [**\OpenAPI\Client\Model\SearchArtworks200ResponseArtworksInner[]**](SearchArtworks200ResponseArtworksInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
