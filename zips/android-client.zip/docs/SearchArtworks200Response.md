

# SearchArtworks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Integer** |  |  [optional]
**number** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**artworks** | [**List&lt;SearchArtworks200ResponseArtworksInner&gt;**](SearchArtworks200ResponseArtworksInner.md) |  |  [optional]




