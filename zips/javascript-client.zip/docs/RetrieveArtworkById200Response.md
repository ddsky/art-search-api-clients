# ArtsearchJs.RetrieveArtworkById200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**startDate** | **Number** |  | [optional] 
**endDate** | **Number** |  | [optional] 
**description** | **String** |  | [optional] 


