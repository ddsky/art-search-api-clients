# ArtsearchJs.SearchArtworks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**offset** | **Number** |  | [optional] 
**artworks** | [**[SearchArtworks200ResponseArtworksInner]**](SearchArtworks200ResponseArtworksInner.md) |  | [optional] 


